
package raycaster;

public abstract class Camera {
    
    abstract Ray generateRay(float x, float y);
    
}
